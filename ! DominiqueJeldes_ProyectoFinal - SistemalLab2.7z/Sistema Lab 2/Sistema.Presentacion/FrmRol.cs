﻿using Sistema.Negocios;
using System;
using System.Windows.Forms;

namespace Sistema.Presentacion
{
    public partial class FrmRol : Form
    {
        public FrmRol()
        {
            InitializeComponent();
        }

        private void Listar()
        {
            try
            {
                dgvListado.DataSource = NRol.Listar();
                this.Formato();
                lblTotal.Text = "Total de registro: " + dgvListado.RowCount.ToString();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void Formato()
        {
            dgvListado.Columns[0].Width = 55;
            dgvListado.Columns[0].HeaderText = "ID";
            dgvListado.Columns[1].Width = 115;
            dgvListado.Columns[1].HeaderText = "Nombre";
        }

        private void FrmRol_Load(object sender, EventArgs e)
        {
            this.Listar();
            this.Formato();
        }
    }
}
