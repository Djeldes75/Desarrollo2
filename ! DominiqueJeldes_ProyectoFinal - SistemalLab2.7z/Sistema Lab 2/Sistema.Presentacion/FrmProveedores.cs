﻿using Sistema.Negocios;
using System;
using System.Windows.Forms;


namespace Sistema.Presentacion
{
    public partial class FrmProveedores : Form
    {
        string nombreAnt;
        public FrmProveedores()
        {
            InitializeComponent();
        }

        private void FrmProveedores_Load(object sender, EventArgs e)
        {
            this.Listar();
        }

        private void Limpiar()
        {
            txtBuscar.Clear();
            txtNombre.Clear();
            txtId.Clear();
            txtTelefono.Clear();
            txtNumeroDocumento.Clear();
            txtDireccion.Clear();
            txtEmail.Clear();

            btnInsertar.Visible = true;
            errorIcono.Clear();

            dgvListado.Columns[0].Visible = false;
            btnEliminar.Visible = false;
            chkSeleccionar.Checked = false;

        }

        private void Formato()
        {
            dgvListado.Columns[0].Visible = false; //Seleccionar

            dgvListado.Columns[1].Width = 50; //ID
            dgvListado.Columns[2].Width = 100; //TIPO DE PERSONA
            dgvListado.Columns[2].HeaderText = "Tipo Persona"; //ENCABREZADO
            dgvListado.Columns[3].Width = 170; //NOMBRE DEL PROVEEDOR
            dgvListado.Columns[4].Width = 100; //DOCUMENTO
            dgvListado.Columns[4].HeaderText = "Documento"; //ENCABEZADO DOCUMENTO
            dgvListado.Columns[5].HeaderText = "Numero Documento"; //ENCABEZADO NUM DE DOCUMENTO
            dgvListado.Columns[5].Width = 100; //ANCHO DE: NUM. DOC.
            dgvListado.Columns[6].Width = 180; //DIRECCION: ANCHO
            dgvListado.Columns[6].HeaderText = "Dirección"; //DIRECCION ENCABEZADO
            dgvListado.Columns[7].Width = 100; //TELEFONO 
            dgvListado.Columns[7].HeaderText = "Telefono"; //ENCABEZADO
            dgvListado.Columns[8].Width = 189; //CORREO
            dgvListado.Columns[8].HeaderText = "Correo";
        }

        //Metodo mensaje ok
        private void MensajeOK(string mensaje)
        {
            MessageBox.Show(mensaje, "Sistema de Compra y ventas", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void MensajeError(string mensaje)
        {
            MessageBox.Show(mensaje, "Sistema de Compra y ventas", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void Listar()
        {
            try
            {
                dgvListado.DataSource = null;
                dgvListado.DataSource = NPersona.ListarProveedores();
                this.Formato();
                lblTotal.Text = $"Total registros: {dgvListado.RowCount}";
                dgvListado.Refresh(); // Actualización explícita
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Eliminar()
        {
            try
            {
                DialogResult opcion = MessageBox.Show("Desea eliminar los registros?", "Sistema de compra y ventas", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                if (opcion == DialogResult.OK)
                {
                    int codigo; // Para obtener el id del usuario seleccionado
                    string respuesta = "";

                    foreach (DataGridViewRow row in dgvListado.Rows)
                    {
                        if (Convert.ToBoolean(row.Cells[0].Value))
                        {
                            //obtener el id del usuario en esa fila o row
                            codigo = Convert.ToInt32(row.Cells[1].Value);
                            respuesta = NPersona.Eliminar(codigo);

                            if (respuesta == "Realizado sin fallos")
                            {
                                this.MensajeOK("Se eliminó correctamente el proveedor");
                            }
                            else
                            {
                                this.MensajeError(respuesta);
                            }
                        }

                    }
                    this.Listar();
                }
            }
            catch (Exception)
            {

                MessageBox.Show("No se pudo eliminar el proveedor");
            }
        }

        private void Buscar()
        {
            try
            {
                dgvListado.DataSource = NPersona.BuscarProveedores(txtBuscar.Text);
                this.Formato();
                lblTotal.Text = "Total de Registros: " + dgvListado.RowCount.ToString();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }
        private void Insertar()
        {
            try
            {
                string respuesta = "";
                if (txtNombre.Text == string.Empty)
                {
                    this.MensajeError("Debe completar los campos obligatorios");
                    errorIcono.SetError(txtNombre, "Debe introducir un nombre");
                    return;
                }
                else
                {
                    respuesta = NPersona.Insertar("Proveedor", txtNombre.Text.Trim(),
                        cmbTipoDocumento.Text, txtNumeroDocumento.Text.Trim(),
                        txtDireccion.Text.Trim(), txtTelefono.Text, txtEmail.Text);

                    if (respuesta.Equals("Realizado sin fallos"))
                    {
                        this.MensajeOK("Proveedor insertado correctamente.");
                        this.Listar(); // <- Actualiza primero el DataGridView
                        this.Limpiar(); // <- Luego limpia los campos
                        TabPrincipal.SelectedIndex = 0;
                    }
                    else
                    {
                        this.MensajeError(respuesta);
                    }
                }
            }
            catch (Exception ex)
            {

                MensajeError(ex.Message);
            }

        }

        private void Actualizar()
        {
            try
            {
                string respuesta = "";
                if (
                    txtId.Text == string.Empty ||
                    txtNombre.Text == string.Empty)
                {
                    this.MensajeError("Debe completar los campos obligatorios");
                    errorIcono.SetError(txtNombre, "Debe de introducir un nombre");
                    errorIcono.SetError(txtId, "El ID no debe estar vacio");
                }
                else
                {
                    respuesta = NPersona.Actualizar(Convert.ToInt32(txtId.Text), "Proveedor", nombreAnt,
                        txtNombre.Text.Trim(),
                        cmbTipoDocumento.Text, txtNumeroDocumento.Text.Trim(), txtDireccion.Text.Trim(),
                        txtTelefono.Text, txtEmail.Text);
                    if (respuesta.Equals("Realizado sin fallos"))
                    {
                        this.MensajeOK("Se actualizo correctamente el registro.");
                        this.Limpiar();
                        this.Listar();
                        TabPrincipal.SelectedIndex = 0;
                    }
                    else
                    {
                        this.MensajeError(respuesta);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            this.Buscar();
        }

        private void btnInsertar_Click(object sender, EventArgs e)
        {
            this.Insertar();
            TabPrincipal.SelectedIndex = 0;
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Limpiar();
            btnActualizar.Visible = false;
            TabPrincipal.SelectedIndex = 0;
        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            this.Actualizar();
            btnActualizar.Visible = false;
        }

        private void dgvListado_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                this.Limpiar();
                btnActualizar.Visible = true;
                btnInsertar.Visible = false;
                txtId.Text = Convert.ToString(dgvListado.CurrentRow.Cells["ID"].Value);
                txtNombre.Text = Convert.ToString(dgvListado.CurrentRow.Cells["Nombre"].Value);
                nombreAnt = Convert.ToString(dgvListado.CurrentRow.Cells["Nombre"].Value);
                cmbTipoDocumento.Text = Convert.ToString(dgvListado.CurrentRow.Cells["tipo_documento"].Value);
                txtNumeroDocumento.Text = Convert.ToString(dgvListado.CurrentRow.Cells["num_documento"].Value);
                txtDireccion.Text = Convert.ToString(dgvListado.CurrentRow.Cells["direccion"].Value);
                txtTelefono.Text = Convert.ToString(dgvListado.CurrentRow.Cells["telefono"].Value);
                txtEmail.Text = Convert.ToString(dgvListado.CurrentRow.Cells["email"].Value);

                TabPrincipal.SelectedIndex = 1;
            }
            catch (Exception ex)
            {

                MessageBox.Show("Seleccione una celda a partir de su nombre");
            }
        }

        private void chkSeleccionar_CheckedChanged(object sender, EventArgs e)
        {
            if (chkSeleccionar.Checked)
            {
                btnEliminar.Visible = true;
                dgvListado.Columns[0].Visible = true;
            }
            else
            {
                btnEliminar.Visible = false;
                dgvListado.Columns[0].Visible = false;
            }
        }

        private void dgvListado_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == dgvListado.Columns["Seleccionar"].Index)
            {
                DataGridViewCheckBoxCell chkSeleccion = (DataGridViewCheckBoxCell)dgvListado.Rows[e.RowIndex].Cells["Seleccionar"];
                chkSeleccion.Value = !Convert.ToBoolean(chkSeleccion.Value);
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            this.Eliminar();
        }
    }
}
