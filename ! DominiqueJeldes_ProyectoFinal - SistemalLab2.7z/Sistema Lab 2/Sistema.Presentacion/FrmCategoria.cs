﻿using Sistema.Negocios;
using System;
using System.Windows.Forms;

namespace Sistema.Presentacion
{
    public partial class FrmCategoria : Form
    {
        string nombreAnt;
        public FrmCategoria()
        {
            InitializeComponent();
        }


        #region Metodos auxiliares


        private void Formato()
        {
            dgvListado.Columns[0].Visible = false;
            dgvListado.Columns[1].Visible = false;
            dgvListado.Columns[2].Width = 150;
            dgvListado.Columns[3].Width = 400;
            dgvListado.Columns[3].HeaderText = "Descripción";
            dgvListado.Columns[4].Width = 150;
        }

        private void Limpiar()
        {
            txtBuscar.Clear();
            btnActivar.Visible = false;
            btnDesactivar.Visible = false;
            btnEliminar.Visible = false;
            btnInsertar.Visible = true;
            btnActualizar.Visible = false;

            dgvListado.Columns[0].Visible = false;
            chkSeleccionar.Checked = false;
            errorIcono.Clear();
            txtDescripcion.Clear();
            txtNombre.Clear();
        }

        private void MensajeOK(string mensaje)
        {
            MessageBox.Show(mensaje, "Sistema de Compra y ventas", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void MensajeError(string mensaje)
        {
            MessageBox.Show(mensaje, "Sistema de Compra y ventas", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        #endregion

        //Buscar una categoria
        private void Buscar(string valor)
        {
            try
            {
                dgvListado.DataSource = NCategoria.Buscar(txtBuscar.Text);
                this.Formato();
                lblTotal.Text = $"Total de registros {dgvListado.RowCount}";
            }
            catch (Exception)
            {

                throw;
            }
        }

        //Insertar una categoria
        private void Insertar()
        {
            try
            {
                string respuesta = "";
                if (txtNombre.Text == string.Empty)
                {
                    this.MensajeError("Debe completar los campos obligatorios");
                    errorIcono.SetError(txtNombre, "Debe de introducir un nombre");
                }
                else
                {
                    respuesta = NCategoria.Insertar(txtNombre.Text, txtDescripcion.Text);
                    if (respuesta.Equals("Realizado sin fallos"))
                    {
                        this.MensajeOK("Se insertó correctamente la categoría");
                        this.Limpiar();
                        TabPrincipal.SelectedIndex = 0;
                        this.Listar();
                    }
                    else
                    {
                        this.MensajeError(respuesta);
                    }
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        //Metodo para listar las categorias 
        private void Listar()
        {
            try
            {
                dgvListado.DataSource = NCategoria.Listar();
                this.Formato();
                this.Limpiar();
                lblTotal.Text = $"Total de registros {dgvListado.RowCount}";
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void FrmCategoria_Load(object sender, EventArgs e)
        {
            this.Listar();
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            this.Buscar(txtBuscar.Text);
        }

        private void btnInsertar_Click(object sender, EventArgs e)
        {
            this.Insertar();
        }

        private void dgvListado_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            string Respuesta = "";
            if (txtNombre.Text == string.Empty || txtId.Text == string.Empty)
            {
                this.MensajeError("Debe completar los campos obligatorios");
                //Puede marcar los errores en el error Icono
            }
            else
            {
                Respuesta = NCategoria.Actualizar(int.Parse(txtId.Text), nombreAnt, txtNombre.Text, txtDescripcion.Text);
                if (Respuesta == "Realizado sin fallos")
                {
                    this.MensajeOK("Se actualizó la categoría");
                    this.Limpiar();
                    TabPrincipal.SelectedIndex = 0;
                    this.Listar();
                }
                else
                {
                    this.MensajeError(Respuesta);
                }

            }
        }

        private void chkSeleccionar_CheckedChanged(object sender, EventArgs e)
        {
            if (chkSeleccionar.Checked)
            {
                btnActivar.Visible = true;
                btnDesactivar.Visible = true;
                btnEliminar.Visible = true;
                dgvListado.Columns[0].Visible = true;
            }
            else
            {
                btnActivar.Visible = false;
                btnDesactivar.Visible = false;
                btnEliminar.Visible = false;
                dgvListado.Columns[0].Visible = false;
            }
        }

        private void dgvListado_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == dgvListado.Columns["Seleccionar"].Index)
            {
                DataGridViewCheckBoxCell chkSeleccion = (DataGridViewCheckBoxCell)dgvListado.Rows[e.RowIndex].Cells["Seleccionar"];
                chkSeleccion.Value = !Convert.ToBoolean(chkSeleccion.Value);
            }
        }

        private void btnDesactivar_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult opcion = MessageBox.Show("Desea desactivar la categoría?", "Sistema de compra y ventas", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                if (opcion == DialogResult.OK)
                {
                    int codigo; // Para obtener el id de las categorias seleccionadas 
                    string respuesta = "";

                    foreach (DataGridViewRow row in dgvListado.Rows)
                    {
                        if (Convert.ToBoolean(row.Cells[0].Value))
                        {
                            //obtener ell id de la categoria en esa fila o row
                            codigo = Convert.ToInt32(row.Cells[1].Value);
                            respuesta = NCategoria.Desctivar(codigo);

                            if (respuesta == "OK")
                            {
                                this.MensajeOK("Se desactivo correctamente la categoria");
                            }
                            else
                            {
                                this.MensajeError(respuesta);
                            }
                        }

                    }
                    this.Listar();
                }
            }
            catch (Exception)
            {

                MessageBox.Show("No se pudo desactivar la categoria");
            }
        }

        private void btnActivar_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult opcion = MessageBox.Show("Desea activar la categoría?", "Sistema de compra y ventas", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                if (opcion == DialogResult.OK)
                {
                    int codigo; // Para obtener el id de las categorias seleccionadas 
                    string respuesta = "";

                    foreach (DataGridViewRow row in dgvListado.Rows)
                    {
                        if (Convert.ToBoolean(row.Cells[0].Value))
                        {
                            //obtener ell id de la categoria en esa fila o row
                            codigo = Convert.ToInt32(row.Cells[1].Value);
                            respuesta = NCategoria.Activar(codigo);

                            if (respuesta == "OK")
                            {
                                this.MensajeOK("Se activo correctamente la categoria");
                            }
                            else
                            {
                                this.MensajeError(respuesta);
                            }
                        }

                    }
                    this.Listar();
                }
            }
            catch (Exception)
            {

                MessageBox.Show("No se pudo activar la categoria");
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult opcion = MessageBox.Show("Desea eliminar la categoría?", "Sistema de compra y ventas", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                if (opcion == DialogResult.OK)
                {
                    int codigo; // Para obtener el id de las categorias seleccionadas 
                    string respuesta = "";

                    foreach (DataGridViewRow row in dgvListado.Rows)
                    {
                        if (Convert.ToBoolean(row.Cells[0].Value))
                        {
                            //obtener ell id de la categoria en esa fila o row
                            codigo = Convert.ToInt32(row.Cells[1].Value);
                            respuesta = NCategoria.Eliminar(codigo);

                            if (respuesta == "OK")
                            {
                                this.MensajeOK("Se eliminó correctamente la categoria");
                            }
                            else
                            {
                                this.MensajeError(respuesta);
                            }
                        }

                    }
                    this.Listar();
                }
            }
            catch (Exception)
            {

                MessageBox.Show("No se pudo eliminar la categoria");
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Limpiar();
            TabPrincipal.SelectedIndex = 0;
        }

        private void txtId_TextChanged(object sender, EventArgs e)
        {

        }

        private void dgvListado_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                this.Limpiar();
                btnActualizar.Visible = true;
                btnInsertar.Visible = false;
                txtId.Text = Convert.ToString(dgvListado.CurrentRow.Cells["ID"].Value);
                txtNombre.Text = Convert.ToString(dgvListado.CurrentRow.Cells["Nombre"].Value);
                nombreAnt = Convert.ToString(dgvListado.CurrentRow.Cells["Nombre"].Value);
                txtDescripcion.Text = Convert.ToString(dgvListado.CurrentRow.Cells["Descripcion"].Value);
                TabPrincipal.SelectedIndex = 1;


            }
            catch (Exception ex)
            {

                MessageBox.Show("Seleccione una celda a partir de su nombre");
            }
        }
    }
}
