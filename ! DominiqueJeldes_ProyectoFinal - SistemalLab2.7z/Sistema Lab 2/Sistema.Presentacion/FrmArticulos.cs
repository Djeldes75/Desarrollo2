﻿using Sistema.Negocios;
using System;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Windows.Forms;
using ZXing;
using ZXing.Common;
using ZXing.QrCode.Internal;

namespace Sistema.Presentacion
{

    public partial class FrmArticulos : Form
    {
        object idarticulo;
        string nombreAnt;
        DataTable categoria = NArticulo.FiltroCategoria();
        public FrmArticulos()
        {
            InitializeComponent();
        }
        private void Formato()
        {

            dgvListado.Columns[0].Visible = false;
            dgvListado.Columns[2].Visible = false;
            dgvListado.Columns[3].Width = 170; //Categoria
            dgvListado.Columns[5].Width = 200; //Nombre
            dgvListado.Columns[6].HeaderText = "Precio Venta";
            dgvListado.Columns[7].Width = 50; //Stock
            dgvListado.Columns[8].Width = 380; //descripcion
            dgvListado.Columns[10].Width = 60; //Estado
        }

        private void Limpiar()
        {
            txtBuscar.Clear();
            btnActivar.Visible = false;
            btnDesactivar.Visible = false;
            btnEliminar.Visible = false;
            btnInsertar.Visible = true;
            btnActualizar.Visible = false;

            errorIcono.Clear();
            chkSeleccionar.Checked = false;
            ptbImagen.Image = null;
            ptbCodigo.Image = null;
            txtDescripcion.Clear();
            txtNombre.Clear();
            txtCodigo.Clear();
            txtPrecio.Clear();
            txtStock.Clear();
            txtImagen.Clear();
        }
        private void Listar()
        {
            try
            {
                dgvListado.DataSource = NArticulo.Listar();
                this.Formato();
                this.Limpiar();
                lblTotal.Text = $"Total de registros {dgvListado.RowCount}";
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void FrmArticulos_Load(object sender, EventArgs e)
        {
            this.Listar();
            this.CargarCategoria();
        }

        private void Buscar(string valor)
        {
            try
            {
                dgvListado.DataSource = NArticulo.Buscar(txtBuscar.Text);
                this.Formato();
                //this.Limpiar();
                lblTotal.Text = $"Total de registros {dgvListado.RowCount}";
            }
            catch (Exception)
            {

                throw;
            }
        }
        private void MensajeOK(string mensaje)
        {
            MessageBox.Show(mensaje, "Sistema de Compra y ventas", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void MensajeError(string mensaje)
        {
            MessageBox.Show(mensaje, "Sistema de Compra y ventas", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void Insertar()
        {
            try
            {
                string respuesta = "";
                if (txtNombre.Text == string.Empty || cmbCategoria.Text == string.Empty
                    || txtPrecio.Text == string.Empty || !Microsoft.VisualBasic.Information.IsNumeric(txtPrecio.Text))
                {
                    this.MensajeError("Debe completar los campos obligatorios");

                    errorIcono.SetError(cmbCategoria, "Debe de introducir una categoria");
                    errorIcono.SetError(txtNombre, "Debe de introducir un nombre");
                    errorIcono.SetError(txtPrecio, "Debe de introducir un precio");
                }


                else
                {
                    respuesta = NArticulo.Insertar(txtNombre.Text, txtDescripcion.Text,
                        Convert.ToInt32(cmbCategoria.SelectedValue), txtCodigo.Text, Convert.ToDecimal(txtPrecio.Text),
                        Convert.ToInt32(txtStock.Text), txtImagen.Text);

                    if (respuesta.Equals("Realizado sin fallos"))
                    {
                        this.MensajeOK("Se insertó correctamente el articulo");
                        this.Listar();

                        errorIcono.Clear();
                        ptbCodigo.Image = null;
                        ptbImagen.Image = null;
                        txtDescripcion.Clear();
                        txtNombre.Clear();
                        //cmbCategoria.Items.Clear();
                        txtCodigo.Clear();
                        txtPrecio.Clear();
                        txtStock.Clear();
                        txtImagen.Clear();
                        TabPrincipal.SelectedIndex = 0;
                    }
                    else
                    {
                        this.MensajeError(respuesta);
                    }
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void dgvListado_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == dgvListado.Columns["Seleccionar"].Index)
            {
                DataGridViewCheckBoxCell chkSeleccion = (DataGridViewCheckBoxCell)dgvListado.Rows[e.RowIndex].Cells["Seleccionar"];
                chkSeleccion.Value = !Convert.ToBoolean(chkSeleccion.Value);
            }
        }

        private void cmbCategoria_SelectedIndexChanged(object sender, EventArgs e)
        {
            //cmbCategoria.Text = cmbCategoria.SelectedValue.ToString();
        }

        private void CargarCategoria()
        {
            cmbCategoria.DataSource = NArticulo.FiltroCategoria();
            cmbCategoria.DisplayMember = "nombre";
            cmbCategoria.ValueMember = "idcategoria";
        }

        private void cmbCategoria_Click(object sender, EventArgs e)
        {
            //CargarCategoria();
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            this.Buscar(txtBuscar.Text);
        }

        private void btnInsertar_Click(object sender, EventArgs e)
        {
            this.Insertar();
        }

        private void dgvListado_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            /*
            try
            {
                this.Limpiar();
                btnActualizar.Visible = true;
                btnInsertar.Visible = false;
                txtId.Text = Convert.ToString(dgvListado.CurrentRow.Cells["ID"].Value);
                txtNombre.Text = Convert.ToString(dgvListado.CurrentRow.Cells["Nombre"].Value);
                nombreAnt = Convert.ToString(dgvListado.CurrentRow.Cells["Nombre"].Value);
                cmbCategoria.SelectedValue = Convert.ToString(dgvListado.CurrentRow.Cells["idcategoria"].Value);
                txtCodigo.Text = Convert.ToString(dgvListado.CurrentRow.Cells["codigo"].Value);
                txtPrecio.Text = Convert.ToString(dgvListado.CurrentRow.Cells["precio_venta"].Value);
                txtStock.Text = Convert.ToString(dgvListado.CurrentRow.Cells["stock"].Value);
                txtDescripcion.Text = Convert.ToString(dgvListado.CurrentRow.Cells["descripcion"].Value);
                txtImagen.Text = Convert.ToString(dgvListado.CurrentRow.Cells["Imagen"].Value);
                //this.CargarCategoria();

                TabPrincipal.SelectedIndex = 1;
                /*
                DataTable categoria = NArticulo.FiltroCategoria();
                
                int rows = categoria.Rows.Count;
                string[] nombre = new string[rows - 1];
                string prueba = categoria.Rows[0][1].ToString();

                for (int i = 0; i < rows; i++)
                {
                    if (categoria.Rows [i][0].ToString() == cmbCategoria.Text)
                    {
                        cmbCategoria.Text = categoria.Rows[i][1].ToString();
                    }
                }
                
            }
            catch (Exception ex)
            {

                MessageBox.Show("Seleccione una celda a partir de su nombre");
            }
            */
        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            string Respuesta = "";
            if (txtNombre.Text == string.Empty || txtId.Text == string.Empty)
            {
                this.MensajeError("Debe completar los campos obligatorios");
                //Puede marcar los errores en el error Icono
            }
            else
            {
                try
                {
                    Respuesta = NArticulo.Actualizar(int.Parse(txtId.Text), nombreAnt, txtNombre.Text,
                        txtDescripcion.Text, Convert.ToInt32(cmbCategoria.SelectedValue), txtCodigo.Text,
                        decimal.Parse(txtPrecio.Text), int.Parse(txtStock.Text), txtImagen.Text);

                    errorIcono.Clear();
                    chkSeleccionar.Checked = false;
                    txtDescripcion.Clear();
                    txtNombre.Clear();
                    //cmbCategoria.Items.Clear();

                    txtCodigo.Clear();
                    ptbCodigo.Image = null;
                    ptbImagen.Image = null;
                    txtPrecio.Clear();
                    txtStock.Clear();
                    txtImagen.Clear();

                    btnActualizar.Enabled = false;
                    btnActualizar.Visible = false;
                    btnInsertar.Visible = true;
                    btnInsertar.Enabled = true;

                    this.MensajeOK("Se actualizó el articulo");
                    this.Listar();
                    TabPrincipal.SelectedIndex = 0;

                }
                catch (Exception ex)
                {

                    MessageBox.Show("Por favor, seleccione una categoria manualmente." + ex);
                }
            }
        }

        private void chkSeleccionar_CheckedChanged(object sender, EventArgs e)
        {
            if (chkSeleccionar.Checked)
            {
                btnActivar.Visible = true;
                btnDesactivar.Visible = true;
                btnEliminar.Visible = true;
                dgvListado.Columns[0].Visible = true;
            }
            else
            {
                btnActivar.Visible = false;
                btnDesactivar.Visible = false;
                btnEliminar.Visible = false;
                dgvListado.Columns[0].Visible = false;
            }
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void btnGenerar_Click(object sender, EventArgs e)
        {
            try
            {
                // Validar entrada
                if (string.IsNullOrWhiteSpace(txtCodigo.Text))
                {
                    MessageBox.Show("Debe ingresar un código para generar el código de barras",
                                  "Campo requerido",
                                  MessageBoxButtons.OK,
                                  MessageBoxIcon.Exclamation);
                    return;
                }

                // Configurar generador
                var barcodeWriter = new ZXing.Windows.Compatibility.BarcodeWriter
                {
                    Format = BarcodeFormat.CODE_128,
                    Options = new EncodingOptions
                    {
                        Height = 71,
                        Width = 268,
                        Margin = 15,
                        PureBarcode = false
                    }
                };

                barcodeWriter.Options.Hints.Add(EncodeHintType.CHARACTER_SET, "UTF-8");
                barcodeWriter.Options.Hints.Add(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.H);

                // Generar imagen
                using (var barcodeBitmap = barcodeWriter.Write(txtCodigo.Text.Trim()))
                {
                    // Actualizar
                    if (ptbCodigo.Image != null)
                    {
                        ptbCodigo.Image.Dispose();
                    }

                    ptbCodigo.Image = (Image)barcodeBitmap.Clone();
                    ptbCodigo.SizeMode = PictureBoxSizeMode.CenterImage;
                }
            }
            catch (ArgumentException ex)
            {
                MessageBox.Show($"Error en el formato del código: {ex.Message}\nUse solo caracteres válidos para CODE 128",
                              "Error de formato",
                              MessageBoxButtons.OK,
                              MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error generando código de barras: {ex.Message}",
                              "Error crítico",
                              MessageBoxButtons.OK,
                              MessageBoxIcon.Error);
            }
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            try
            {
                // Validación 1: Verificar si hay código de barras
                if (ptbCodigo.Image == null)
                {
                    MessageBox.Show("No hay código de barras para guardar",
                                   "Advertencia",
                                   MessageBoxButtons.OK,
                                   MessageBoxIcon.Warning);
                    return;
                }

                // Validación 2: Verificar código del artículo
                if (string.IsNullOrWhiteSpace(txtCodigo.Text))
                {
                    MessageBox.Show("El código del artículo es requerido",
                                   "Error",
                                   MessageBoxButtons.OK,
                                   MessageBoxIcon.Error);
                    return;
                }

                // Ruta fija y nombre automático
                string directorioCodigos = @"C:\VSProjects\DesarolloSoftware2\Sistema Lab 2\Sistema Lab 2\Sistema.Presentacion\Resources\Barcodes\";
                string rutaCompleta = Path.Combine(directorioCodigos, $"{txtCodigo.Text.Trim()}.png");

                // Guardar directamente en la ruta fija
                ptbCodigo.Image.Save(rutaCompleta, ImageFormat.Png);
                MessageBox.Show("Código guardado exitosamente");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al guardar: {ex.Message}\nAsegúrese de que la carpeta 'Barcodes' exista.",
                                "Error",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
            }
        }

        private void btnImagen_Click(object sender, EventArgs e)
        {
            try
            {
                string directorioBase = @"C:\VSProjects\DesarolloSoftware2\Sistema Lab 2\Sistema Lab 2\Sistema.Presentacion\Resources\ImgArticulos";

                using (var openDialog = new OpenFileDialog())
                {
                    openDialog.Filter = "Imágenes|*.jpg;*.jpeg;*.png;*.bmp";
                    openDialog.InitialDirectory = directorioBase;

                    if (openDialog.ShowDialog() == DialogResult.OK)
                    {
                        // Guardar solo el nombre del archivo
                        txtImagen.Text = Path.GetFileName(openDialog.FileName);

                        // Carga temporal para previsualización
                        ptbImagen.Image = Image.FromFile(openDialog.FileName);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Limpiar();
            TabPrincipal.SelectedIndex = 0;
        }

        private void btnActivar_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult opcion = MessageBox.Show("Desea activar el articulo?", "Sistema de compra y ventas", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                if (opcion == DialogResult.OK)
                {
                    int codigo; // Para obtener el id de las categorias seleccionadas 
                    string respuesta = "";

                    foreach (DataGridViewRow row in dgvListado.Rows)
                    {
                        if (Convert.ToBoolean(row.Cells[0].Value))
                        {
                            //obtener ell id de la categoria en esa fila o row
                            codigo = Convert.ToInt32(row.Cells[1].Value);
                            respuesta = NArticulo.Activar(codigo);

                            if (respuesta == "OK")
                            {
                                this.MensajeOK("Se activo correctamente el articulo");
                            }
                            else
                            {
                                this.MensajeError(respuesta);
                            }
                        }

                    }
                    this.Listar();
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("No se pudo activar el articulo" + ex);
            }
        }

        private void btnDesactivar_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult opcion = MessageBox.Show("Desea desactivar el articulo?", "Sistema de compra y ventas", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                if (opcion == DialogResult.OK)
                {
                    int codigo; // Para obtener el id de las categorias seleccionadas 
                    string respuesta = "";

                    foreach (DataGridViewRow row in dgvListado.Rows)
                    {
                        if (Convert.ToBoolean(row.Cells[0].Value))
                        {
                            //obtener ell id de la categoria en esa fila o row
                            codigo = Convert.ToInt32(row.Cells[1].Value);
                            respuesta = NArticulo.Desctivar(codigo);

                            if (respuesta == "OK")
                            {
                                this.MensajeOK("Se desactivo correctamente el articulo");
                            }
                            else
                            {
                                this.MensajeError(respuesta);
                            }
                        }

                    }
                    this.Listar();
                }
            }
            catch (Exception)
            {

                MessageBox.Show("No se pudo desactivar el articulo");
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult opcion = MessageBox.Show("Desea eliminar el articulo?", "Sistema de compra y ventas", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                if (opcion == DialogResult.OK)
                {
                    int codigo; // Para obtener el id de las categorias seleccionadas 
                    string respuesta = "";

                    foreach (DataGridViewRow row in dgvListado.Rows)
                    {
                        if (Convert.ToBoolean(row.Cells[0].Value))
                        {
                            //obtener ell id de la categoria en esa fila o row
                            codigo = Convert.ToInt32(row.Cells[1].Value);
                            respuesta = NArticulo.Eliminar(codigo);

                            if (respuesta == "OK")
                            {
                                this.MensajeOK("Se eliminó correctamente el articulo");
                            }
                            else
                            {
                                this.MensajeError(respuesta);
                            }
                        }

                    }
                    this.Listar();
                }
            }
            catch (Exception)
            {

                MessageBox.Show("No se pudo eliminar el articulo.");
            }
        }

        private void dgvListado_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {

            this.Limpiar();
            btnActualizar.Visible = true;
            btnActualizar.Enabled = true;
            btnInsertar.Visible = false;

            //Datos del registro
            txtId.Text = Convert.ToString(dgvListado.CurrentRow.Cells["ID"].Value);
            txtNombre.Text = Convert.ToString(dgvListado.CurrentRow.Cells["Nombre"].Value);
            nombreAnt = Convert.ToString(dgvListado.CurrentRow.Cells["Nombre"].Value);
            cmbCategoria.SelectedValue = Convert.ToString(dgvListado.CurrentRow.Cells["idcategoria"].Value);
            txtCodigo.Text = Convert.ToString(dgvListado.CurrentRow.Cells["codigo"].Value);
            txtPrecio.Text = Convert.ToString(dgvListado.CurrentRow.Cells["precio_venta"].Value);
            txtStock.Text = Convert.ToString(dgvListado.CurrentRow.Cells["stock"].Value);
            txtDescripcion.Text = Convert.ToString(dgvListado.CurrentRow.Cells["descripcion"].Value);
            txtImagen.Text = Convert.ToString(dgvListado.CurrentRow.Cells["Imagen"].Value);

            //Cargar imagen y código de barras
            try
            {
                // Directorios base
                string directorioImagenes = @"C:\VSProjects\DesarolloSoftware2\Sistema Lab 2\Sistema Lab 2\Sistema.Presentacion\Resources\ImgArticulos\";
                string directorioCodigos = @"C:\VSProjects\DesarolloSoftware2\Sistema Lab 2\Sistema Lab 2\Sistema.Presentacion\Resources\Barcodes\";

                // 1. Cargar imagen del artículo
                if (!string.IsNullOrEmpty(txtImagen.Text))
                {
                    string rutaImagen = Path.Combine(directorioImagenes, txtImagen.Text.Trim());

                    if (File.Exists(rutaImagen))
                    {
                        using (Image tempImage = Image.FromFile(rutaImagen))
                        {
                            ptbImagen.Image?.Dispose();
                            ptbImagen.Image = new Bitmap(tempImage);
                        }
                    }
                    else
                    {
                        // MessageBox.Show($"Ruta buscada: {rutaImagen}"); //Para revisar la ruta
                        MessageBox.Show("Imagen no encontrada.",
                                      "Advertencia",
                                      MessageBoxButtons.OK,
                                      MessageBoxIcon.Warning);
                        //
                    }
                }

                // 2. Cargar código de barras
                if (!string.IsNullOrEmpty(txtCodigo.Text))
                {
                    string rutaCodigo = Path.Combine(directorioCodigos, $"{txtCodigo.Text}.png");

                    if (File.Exists(rutaCodigo))
                    {
                        using (Image codigoImg = Image.FromFile(rutaCodigo))
                        {
                            ptbCodigo.Image?.Dispose();
                            ptbCodigo.Image = new Bitmap(codigoImg);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error cargando recursos: {ex.Message}",
                              "Error",
                              MessageBoxButtons.OK,
                              MessageBoxIcon.Error);
            }

            TabPrincipal.SelectedIndex = 1;
        }
    }
}

