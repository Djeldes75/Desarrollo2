﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema.Presentacion
{
    public class Variables
    {
        public static int IdUsuario;
        public static int IdProveedor;
        public static string NombreProveedor;

        public static int IdCliente;
        public static string NombreCliente;
        public static int Stock;

        public static int IdArticulo;
        public static string Codigo, Nombre;
        public static decimal Precio;
    }
}
