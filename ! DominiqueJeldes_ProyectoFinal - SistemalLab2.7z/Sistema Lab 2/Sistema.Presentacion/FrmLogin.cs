﻿using Sistema.Negocios;
using System;
using System.Data;
using System.Windows.Forms;

namespace Sistema.Presentacion
{
    public partial class FrmLogin : Form
    {
        public FrmLogin()
        {
            InitializeComponent();
        }

        private void Limpiar()
        {
            txtEmail.Clear();
            txtClave1.Clear();
        }

        //metodo para preguntarle al usuario si de verdad quiere salir
        private void Cerrar()
        {
            DialogResult opcion = MessageBox.Show("Desea salir del sistema?", "Sistema de compra y ventas", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if (opcion == DialogResult.OK)
            {
                Application.Exit();
            }
        }
        private void btnAccesar_Click(object sender, EventArgs e)
        {
            DataTable Tabla = new DataTable();
            Tabla = NUsuario.Login(txtEmail.Text, txtClave1.Text);

            if (Tabla.Rows.Count <= 0)
            {
                MessageBox.Show("El email o la clave son incorrectos", "Sistema de Compra y venta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (Convert.ToBoolean(Tabla.Rows[0][4]) == false)
                {
                    MessageBox.Show("El usuario esta inactivo", "Sistema de Compra y venta", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    FrmPrincipal frm = new FrmPrincipal();

                    frm.IdUsuario = Convert.ToInt32(Tabla.Rows[0][0]);
                    Variables.IdUsuario = Convert.ToInt32(Tabla.Rows[0][0]);
                    frm.IdRol = Convert.ToInt32(Tabla.Rows[0][1]);
                    frm.Rol = Convert.ToString(Tabla.Rows[0][2]);
                    frm.Nombre = Convert.ToString(Tabla.Rows[0][3]);
                    frm.Estado = Convert.ToBoolean(Tabla.Rows[0][4]);

                    frm.Show();
                    this.Hide();
                }
            }
        }

        private void FrmLogin_Load(object sender, EventArgs e)
        {

        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Limpiar();
            this.Cerrar();
        }

        private void txtClave1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                this.btnAccesar_Click(sender, e);
            }
        }
    }
}
