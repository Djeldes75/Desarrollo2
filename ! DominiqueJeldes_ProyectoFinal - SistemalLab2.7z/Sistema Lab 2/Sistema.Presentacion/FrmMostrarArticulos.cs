﻿using Sistema.Negocios;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sistema.Presentacion
{
    public partial class FrmMostrarArticulos : Form
    {
        public FrmMostrarArticulos()
        {
            InitializeComponent();
        }

        private void FrmMostrarArticulos_Load(object sender, EventArgs e)
        {

        }
        private void Buscar(string valor)
        {
            try
            {
                dgvListado.DataSource = NArticulo.Buscar(txtBuscar.Text);
                this.Formato();
                //this.Limpiar();
                lblTotal.Text = $"Total de registros {dgvListado.RowCount}";
            }
            catch (Exception)
            {

                throw;
            }
        }
        private void Formato()
        {

            dgvListado.Columns[0].Visible = false;
            dgvListado.Columns[2].Visible = false;
            dgvListado.Columns[8].Width = 400;
            dgvListado.Columns[6].HeaderText = "Precio Venta";

        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            //this.Buscar(txtBuscar.Text);
        }

        private void dgvListado_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            /*
            Variables.IdArticulo = Convert.ToInt32(dgvListado.CurrentRow.Cells["ID"].Value);
            Variables.Codigo = Convert.ToString(dgvListado.CurrentRow.Cells["Codigo"].Value);
            Variables.Nombre = Convert.ToString(dgvListado.CurrentRow.Cells["Nombre"].Value);
            Variables.Precio = Convert.ToDecimal(dgvListado.CurrentRow.Cells["Precio_Venta"].Value);
            Variables.Stock = Convert.ToInt32(dgvListado.CurrentRow.Cells["Stock"].Value);
            */
        }
    }
}
