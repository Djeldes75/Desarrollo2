﻿using System;
using System.Data.SqlClient;

namespace Sistema.Datos
{
    internal class Conexion
    {
        //atributos para la conexion
        private string Basedatos;
        private string Servidor;
        private string Usuario;
        private string Password;
        private bool Seguridad;

        private static Conexion conn;


        //constructor
        private Conexion()
        {
            this.Basedatos = "SISTEMA";
            this.Servidor = "KAIROS\\SISTEMA";
            this.Usuario = "sa";
            this.Password = "";
            this.Seguridad = true;
        }

        //crear un metodo que nos permita establecer
        //la cadena de conexion
        public SqlConnection CrearConexion()
        {
            SqlConnection cadena = new SqlConnection();

            try
            {
                cadena.ConnectionString = "Server=" + this.Servidor + ";Database=" + this.Basedatos + ";";
                if (this.Seguridad)
                {
                    cadena.ConnectionString += "Integrated Security = SSPI";
                }
                else
                {
                    cadena.ConnectionString += "User Id=" + this.Usuario + ";Password=" + this.Password;
                }
            }
            catch (Exception ex)
            {
                cadena = null;
                throw ex;
            }
            return cadena;
        }

        //Obtener la instancia de la conexion
        public static Conexion getInstancia()
        {
            if (conn == null)
            {
                conn = new Conexion();
            }
            return conn;
        }


    }
}
