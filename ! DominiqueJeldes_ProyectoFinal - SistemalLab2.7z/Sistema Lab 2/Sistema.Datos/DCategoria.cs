﻿using Sistema.Entidad;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Sistema.Datos
{
    public class DCategoria
    {
        //Listar las categorias
        public DataTable Listar()
        {
            SqlDataReader Resultado;
            DataTable Tabla = new DataTable();
            SqlConnection sqlCon = new SqlConnection();

            try
            {
                sqlCon = Conexion.getInstancia().CrearConexion();
                SqlCommand Comando = new SqlCommand("categoria_listar", sqlCon);
                Comando.CommandType = CommandType.StoredProcedure;
                sqlCon.Open();
                Resultado = Comando.ExecuteReader();
                Tabla.Load(Resultado);
            }
            catch (Exception ex)
            {

                throw ex;
            }
            finally
            {
                if (sqlCon.State == ConnectionState.Open)
                {
                    sqlCon.Close();
                }
            }

            return Tabla;
        }
        //Buscar Categorias

        public DataTable Buscar(string valor)
        {
            SqlDataReader Resultado;
            DataTable Tabla = new DataTable();
            SqlConnection sqlCon = new SqlConnection();

            try
            {
                sqlCon = Conexion.getInstancia().CrearConexion();
                SqlCommand Comando = new SqlCommand("categoria_buscar", sqlCon);
                Comando.CommandType = CommandType.StoredProcedure;
                Comando.Parameters.Add("@valor", SqlDbType.VarChar).Value = valor;
                sqlCon.Open();
                Resultado = Comando.ExecuteReader();
                Tabla.Load(Resultado);

            }
            catch (Exception error)
            {
                throw error;
            }
            finally
            {
                if (sqlCon.State == ConnectionState.Open)
                {
                    sqlCon.Close();
                }
            }
            return Tabla;

        }
        //Determinar si una categoria existe en la base de datos
        public string Existe(string valor)
        {
            string Respuesta = "";
            SqlConnection sqlCon = new SqlConnection();
            try
            {
                sqlCon = Conexion.getInstancia().CrearConexion();
                SqlCommand Comando = new SqlCommand("categoria_existe",sqlCon);
                Comando.CommandType=CommandType.StoredProcedure;
                Comando.Parameters.Add("@valor",SqlDbType.VarChar).Value = valor;
                SqlParameter ParametroExiste = new SqlParameter();
                ParametroExiste.ParameterName = "@existe";
                ParametroExiste.SqlDbType = SqlDbType.Int;
                ParametroExiste.Direction = ParameterDirection.Output;
                Comando.Parameters.Add(ParametroExiste);
                sqlCon.Open();
                Comando.ExecuteNonQuery();
                Respuesta = Convert.ToString(ParametroExiste.Value);
            }
            catch (Exception ex)
            {

                Respuesta = ex.Message;
            }
            finally
            {
                if (sqlCon.State == ConnectionState.Open)
                {
                    sqlCon.Close();
                }
            }
            return Respuesta;
        }
        //Insertar una Categoria
        public string Insertar(Categoria obj)
        {
            string Respuesta = " ";
            SqlConnection sqlCon = new SqlConnection();

            try
            {
                sqlCon = Conexion.getInstancia().CrearConexion();
                SqlCommand Comando = new SqlCommand("categoria_insertar", sqlCon);
                Comando.CommandType = CommandType.StoredProcedure;
                Comando.Parameters.Add("@nombre", SqlDbType.VarChar).Value = obj.Nombre;
                Comando.Parameters.Add("@descripcion", SqlDbType.VarChar).Value = obj.Descripcion;
                sqlCon.Open();
                Respuesta = Comando.ExecuteNonQuery() == 1 ? "Realizado sin fallos" : "No se pudo insertar la categoria";

            }
            catch (Exception error)
            {
                throw error;
            }
            finally
            {
                if (sqlCon.State == ConnectionState.Open)
                {
                    sqlCon.Close();
                }
            }
            return Respuesta;

        }
        //Actualizar una categoria
        public string Actualizar(Categoria obj)
        {
            string Respuesta = " ";
            SqlConnection sqlCon = new SqlConnection();

            try
            {
                sqlCon = Conexion.getInstancia().CrearConexion();
                SqlCommand Comando = new SqlCommand("categoria_actualizar", sqlCon);
                Comando.CommandType = CommandType.StoredProcedure;
                Comando.Parameters.Add("@idcategoria", SqlDbType.Int).Value = obj.Idcategoria;
                Comando.Parameters.Add("@nombre", SqlDbType.VarChar).Value = obj.Nombre;
                Comando.Parameters.Add("@descripcion", SqlDbType.VarChar).Value = obj.Descripcion;
                sqlCon.Open();
                Respuesta = Comando.ExecuteNonQuery() == 1 ? "Realizado sin fallos" : "No se pudo actualizar la categoria";

            }
            catch (Exception error)
            {
                throw error;
            }
            finally
            {
                if (sqlCon.State == ConnectionState.Open)
                {
                    sqlCon.Close();
                }
            }
            return Respuesta;
        }

        //Eliminar una categoria
        public string Eliminar(int idcategoria)
        {
            string Respuesta = " ";
            SqlConnection sqlCon = new SqlConnection();

            try
            {
                sqlCon = Conexion.getInstancia().CrearConexion();
                SqlCommand Comando = new SqlCommand("categoria_eliminar", sqlCon);
                Comando.CommandType = CommandType.StoredProcedure;
                Comando.Parameters.Add("@idcategoria", SqlDbType.Int).Value = idcategoria;
                sqlCon.Open();
                Respuesta = Comando.ExecuteNonQuery() == 1 ? "Realizado sin fallos" : "No se pudo eliminar la categoria";

            }
            catch (Exception error)
            {
                throw error;
            }
            finally
            {
                if (sqlCon.State == ConnectionState.Open)
                {
                    sqlCon.Close();
                }
            }
            return Respuesta;
        }

        //Activar una categoria
        public string Activar(int idcategoria)
        {

            string Respuesta = " ";
            SqlConnection sqlCon = new SqlConnection();

            try
            {
                sqlCon = Conexion.getInstancia().CrearConexion();
                SqlCommand Comando = new SqlCommand("categoria_activar", sqlCon);
                Comando.CommandType = CommandType.StoredProcedure;
                Comando.Parameters.Add("@idcategoria", SqlDbType.Int).Value = idcategoria;
                sqlCon.Open();
                Respuesta = Comando.ExecuteNonQuery() == 1 ? "Realizado sin fallos" : "No se pudo activar la categoria";

            }
            catch (Exception error)
            {
                throw error;
            }
            finally
            {
                if (sqlCon.State == ConnectionState.Open)
                {
                    sqlCon.Close();
                }
            }
            return Respuesta;
        }

        //Desactivar categorias
        public string Desactivar(int idcategoria)
        {

            string Respuesta = " ";
            SqlConnection sqlCon = new SqlConnection();

            try
            {
                sqlCon = Conexion.getInstancia().CrearConexion();
                SqlCommand Comando = new SqlCommand("categoria_desactivar", sqlCon);
                Comando.CommandType = CommandType.StoredProcedure;
                Comando.Parameters.Add("@idcategoria", SqlDbType.Int).Value = idcategoria;
                sqlCon.Open();
                Respuesta = Comando.ExecuteNonQuery() == 1 ? "Realizado sin fallos" : "No se pudo desactivar la categoria";

            }
            catch (Exception error)
            {
                throw error;
            }
            finally
            {
                if (sqlCon.State == ConnectionState.Open)
                {
                    sqlCon.Close();
                }
            }
            return Respuesta;

        }

    }    
}
