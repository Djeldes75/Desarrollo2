﻿using Sistema.Entidad;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema.Datos
{
    public class DArticulo
    {
            //Listar las categorias
            public DataTable Listar()
            {
                SqlDataReader Resultado;
                DataTable Tabla = new DataTable();
                SqlConnection sqlCon = new SqlConnection();

                try
                {
                    sqlCon = Conexion.getInstancia().CrearConexion();
                    SqlCommand Comando = new SqlCommand("articulo_listar", sqlCon);
                    Comando.CommandType = CommandType.StoredProcedure;
                    sqlCon.Open();
                    Resultado = Comando.ExecuteReader();
                    Tabla.Load(Resultado);
                }
                catch (Exception ex)
                {

                    throw ex;
                }
                finally
                {
                    if (sqlCon.State == ConnectionState.Open)
                    {
                        sqlCon.Close();
                    }
                }

                return Tabla;
            }
            //Buscar Categorias

            public DataTable Buscar(string valor)
            {
                SqlDataReader Resultado;
                DataTable Tabla = new DataTable();
                SqlConnection sqlCon = new SqlConnection();

                try
                {
                    sqlCon = Conexion.getInstancia().CrearConexion();
                    SqlCommand Comando = new SqlCommand("articulo_buscar", sqlCon);
                    Comando.CommandType = CommandType.StoredProcedure;
                    Comando.Parameters.Add("@valor", SqlDbType.VarChar).Value = valor;
                    sqlCon.Open();
                    Resultado = Comando.ExecuteReader();
                    Tabla.Load(Resultado);

                }
                catch (Exception error)
                {
                    throw error;
                }
                finally
                {
                    if (sqlCon.State == ConnectionState.Open)
                    {
                        sqlCon.Close();
                    }
                }
                return Tabla;

            }
        public DataTable BuscarCodigo(string valor)
        {
            SqlDataReader Resultado;
            DataTable Tabla = new DataTable();
            SqlConnection sqlCon = new SqlConnection();

            try
            {
                sqlCon = Conexion.getInstancia().CrearConexion();
                SqlCommand Comando = new SqlCommand("articulo_buscar_codigo", sqlCon);
                Comando.CommandType = CommandType.StoredProcedure;
                Comando.Parameters.Add("@valor", SqlDbType.VarChar).Value = valor;
                sqlCon.Open();
                Resultado = Comando.ExecuteReader();
                Tabla.Load(Resultado);

            }
            catch (Exception error)
            {
                throw error;
            }
            finally
            {
                if (sqlCon.State == ConnectionState.Open)
                {
                    sqlCon.Close();
                }
            }
            return Tabla;

        }
        //Determinar si una categoria existe en la base de datos
        public DataTable BuscarCodigoVentas(string valor)
        {
            SqlDataReader Resultado;
            DataTable Tabla = new DataTable();
            SqlConnection sqlCon = new SqlConnection();

            try
            {
                sqlCon = Conexion.getInstancia().CrearConexion();
                SqlCommand Comando = new SqlCommand("articulo_buscar_codigo_venta", sqlCon);
                Comando.CommandType = CommandType.StoredProcedure;
                Comando.Parameters.Add("@valor", SqlDbType.VarChar).Value = valor;
                sqlCon.Open();
                Resultado = Comando.ExecuteReader();
                Tabla.Load(Resultado);

            }
            catch (Exception error)
            {
                throw error;
            }
            finally
            {
                if (sqlCon.State == ConnectionState.Open)
                {
                    sqlCon.Close();
                }
            }
            return Tabla;

        }
        public string Existe(string valor)
            {
                string Respuesta = "";
                SqlConnection sqlCon = new SqlConnection();
                try
                {
                    sqlCon = Conexion.getInstancia().CrearConexion();
                    SqlCommand Comando = new SqlCommand("articulo_existe", sqlCon);
                    Comando.CommandType = CommandType.StoredProcedure;
                    Comando.Parameters.Add("@valor", SqlDbType.VarChar).Value = valor;
                    SqlParameter ParametroExiste = new SqlParameter();
                    ParametroExiste.ParameterName = "@existe";
                    ParametroExiste.SqlDbType = SqlDbType.Int;
                    ParametroExiste.Direction = ParameterDirection.Output;
                    Comando.Parameters.Add(ParametroExiste);
                    sqlCon.Open();
                    Comando.ExecuteNonQuery();
                    Respuesta = Convert.ToString(ParametroExiste.Value);
                }
                catch (Exception ex)
                {

                    Respuesta = ex.Message;
                }
                finally
                {
                    if (sqlCon.State == ConnectionState.Open)
                    {
                        sqlCon.Close();
                    }
                }
                return Respuesta;
            }
            //Insertar una Categoria
            public string Insertar(Articulo obj)
            {
                string Respuesta = " ";
                SqlConnection sqlCon = new SqlConnection();

                try
                {
                    sqlCon = Conexion.getInstancia().CrearConexion();
                    SqlCommand Comando = new SqlCommand("articulo_insertar", sqlCon);
                    Comando.CommandType = CommandType.StoredProcedure;
                    Comando.Parameters.Add("@nombre", SqlDbType.VarChar).Value = obj.Nombre;
                    Comando.Parameters.Add("@idcategoria", SqlDbType.Int).Value = obj.Idcategoria;
                    Comando.Parameters.Add("@codigo", SqlDbType.VarChar).Value = obj.Codigo;
                    Comando.Parameters.Add("@precio_venta", SqlDbType.Decimal).Value = obj.Precio_venta;
                    Comando.Parameters.Add("@stock", SqlDbType.Int).Value = obj.Stock;
                    Comando.Parameters.Add("@imagen", SqlDbType.VarChar).Value = obj.Imagen;
                    Comando.Parameters.Add("@descripcion", SqlDbType.VarChar).Value = obj.Descripcion;

                    sqlCon.Open();
                    Respuesta = Comando.ExecuteNonQuery() == 1 ? "Realizado sin fallos" : "No se pudo insertar el articulo";

                }
                catch (Exception error)
                {
                    throw error;
                }
                finally
                {
                    if (sqlCon.State == ConnectionState.Open)
                    {
                        sqlCon.Close();
                    }
                }
                return Respuesta;

            }
            //Actualizar una categoria
            public string Actualizar(Articulo obj)
            {
                string Respuesta = " ";
                SqlConnection sqlCon = new SqlConnection();

                try
                {
                    sqlCon = Conexion.getInstancia().CrearConexion();
                    SqlCommand Comando = new SqlCommand("articulo_actualizar", sqlCon);
                    Comando.CommandType = CommandType.StoredProcedure;
                    Comando.Parameters.Add("@idarticulo", SqlDbType.Int).Value = obj.Idarticulo;
                    Comando.Parameters.Add("@nombre", SqlDbType.VarChar).Value = obj.Nombre;
                    Comando.Parameters.Add("@idcategoria", SqlDbType.Int).Value = obj.Idcategoria;
                    Comando.Parameters.Add("@codigo", SqlDbType.VarChar).Value = obj.Codigo;
                    Comando.Parameters.Add("@precio_venta", SqlDbType.Decimal).Value = obj.Precio_venta;
                    Comando.Parameters.Add("@stock", SqlDbType.Int).Value = obj.Stock;
                    Comando.Parameters.Add("@imagen", SqlDbType.VarChar).Value = obj.Imagen;
                    Comando.Parameters.Add("@descripcion", SqlDbType.VarChar).Value = obj.Descripcion;

                    sqlCon.Open();
                    Respuesta = Comando.ExecuteNonQuery() == 1 ? "Realizado sin fallos" : "No se pudo actualizar el articulo";

                }
                catch (Exception error)
                {
                    throw error;
                }
                finally
                {
                    if (sqlCon.State == ConnectionState.Open)
                    {
                        sqlCon.Close();
                    }
                }
                return Respuesta;
            }

            //Eliminar una categoria
            public string Eliminar(int idarticulo)
            {
                string Respuesta = " ";
                SqlConnection sqlCon = new SqlConnection();

                try
                {
                    sqlCon = Conexion.getInstancia().CrearConexion();
                    SqlCommand Comando = new SqlCommand("articulo_eliminar", sqlCon);
                    Comando.CommandType = CommandType.StoredProcedure;
                    Comando.Parameters.Add("@idarticulo", SqlDbType.Int).Value = idarticulo;
                    sqlCon.Open();
                    Respuesta = Comando.ExecuteNonQuery() == 1 ? "Realizado sin fallos" : "No se pudo eliminar el articulo";

                }
                catch (Exception error)
                {
                    throw error;
                }
                finally
                {
                    if (sqlCon.State == ConnectionState.Open)
                    {
                        sqlCon.Close();
                    }
                }
                return Respuesta;
            }

            //Activar una categoria
            public string Activar(int idarticulo)
            {

                string Respuesta = " ";
                SqlConnection sqlCon = new SqlConnection();

                try
                {
                    sqlCon = Conexion.getInstancia().CrearConexion();
                    SqlCommand Comando = new SqlCommand("articulo_activar", sqlCon);
                    Comando.CommandType = CommandType.StoredProcedure;
                    Comando.Parameters.Add("@idarticulo", SqlDbType.Int).Value = idarticulo;
                    sqlCon.Open();
                    Respuesta = Comando.ExecuteNonQuery() == 1 ? "Realizado sin fallos" : "No se pudo activar el articulo";

                }
                catch (Exception error)
                {
                    throw error;
                }
                finally
                {
                    if (sqlCon.State == ConnectionState.Open)
                    {
                        sqlCon.Close();
                    }
                }
                return Respuesta;
            }

            //Desactivar categorias
            public string Desactivar(int idarticulo)
            {

                string Respuesta = " ";
                SqlConnection sqlCon = new SqlConnection();

                try
                {
                    sqlCon = Conexion.getInstancia().CrearConexion();
                    SqlCommand Comando = new SqlCommand("articulo_desactivar", sqlCon);
                    Comando.CommandType = CommandType.StoredProcedure;
                    Comando.Parameters.Add("@idarticulo", SqlDbType.Int).Value = idarticulo;
                    sqlCon.Open();
                    Respuesta = Comando.ExecuteNonQuery() == 1 ? "Realizado sin fallos" : "No se pudo desactivar el articulo";

                }
                catch (Exception error)
                {
                    throw error;
                }
                finally
                {
                    if (sqlCon.State == ConnectionState.Open)
                    {
                        sqlCon.Close();
                    }
                }
                return Respuesta;

            }

        public DataTable FiltroCategoria()
        {
            SqlDataReader Resultado;
            DataTable Tabla = new DataTable();
            SqlConnection sqlCon = new SqlConnection();

            try
            {
                sqlCon = Conexion.getInstancia().CrearConexion();
                SqlCommand Comando = new SqlCommand("categoria_seleccionar", sqlCon);
                Comando.CommandType = CommandType.StoredProcedure;
                sqlCon.Open();
                Resultado = Comando.ExecuteReader();
                Tabla.Load(Resultado);
            }
            catch (Exception ex)
            {

                throw ex;
            }
            finally
            {
                if (sqlCon.State == ConnectionState.Open)
                {
                    sqlCon.Close();
                }
            }

            return Tabla;
        }


    }
}
