﻿namespace Sistema.Entidad
{
    public class Usuario
    {
        public int IdUsuario { get; set; }   //public int Id { get; set; }
        public int IdRol { get; set; }      //public int RolId { get; set; }        
        public string Nombre { get; set; } //public string Name { get; set; }
        public string TipoDocumento { get; set; }  //public string TipoDocumento { get; set; }
        public string NumeroDocumento { get; set; }  //public string NumDocumento { get; set; }
        public string Direccion { get; set; } //public string Direccion { get; set; }
        public string Telefono { get; set; } // public string Telefono { get; set; }
        public string Email { get; set; }  //public string Email { get; set; }
        public string Clave { get; set; } //public string Clave { get; set; }
        public bool Estado { get; set; } //public bool Estado { get; set; }
    }
}
