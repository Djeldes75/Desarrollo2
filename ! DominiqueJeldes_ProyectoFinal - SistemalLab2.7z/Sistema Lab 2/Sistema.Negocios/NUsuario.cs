﻿using Sistema.Datos;
using Sistema.Entidad;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema.Negocios
{
    public class NUsuario
    {
        public static DataTable Listar()
        {
            DUsuario datos = new DUsuario();
            return datos.Listar();
        }

        public static DataTable Buscar(string valor)
        {
            //instanciamos DCategoria
            DUsuario datos = new DUsuario();
            return datos.Buscar(valor);
        }

        public static string Insertar(int idrol, string nombre, string tipodocumento, string numeroDocumento, string direccion, string telefono, string email, string clave)
        {
            //instanciamos a la clase Dcategoria
            DUsuario datos = new DUsuario();

            //Primero debemos validar si la categoria existe
            string existe = datos.Existe(email);
            if (existe.Equals("1"))
            {
                return "La Categoría ya Existe";
            }
            else
            {
                Usuario obj = new Usuario();
                obj.Nombre = nombre;
                obj.IdRol = idrol;
                obj.TipoDocumento = tipodocumento;
                obj.NumeroDocumento = numeroDocumento;
                obj.Direccion = direccion;
                obj.Telefono = telefono;
                obj.Email = email;
                obj.Clave = clave;
                return datos.Insertar(obj);

            }



        }
        public static string Actualizar(int idusuario,int idrol, string nombre, string tipodocumento, string numeroDocumento, string direccion, string telefono, string email, string clave, string emailant)
        {
            //Instanciamos a la classe DCategoria 
            DUsuario datos = new DUsuario();
            Usuario obj = new Usuario();

            if (emailant.Equals(email))
            {
                //la categoria existe, por ende solo creamos el objeto
                obj.IdUsuario = idusuario;
                obj.IdRol = idrol;
                obj.Nombre = nombre;
                obj.TipoDocumento = tipodocumento;
                obj.NumeroDocumento = numeroDocumento;
                obj.Direccion = direccion;
                obj.Telefono = telefono;
                obj.Email = email;
                obj.Clave = clave;
                return datos.Actualizar(obj);
            }
            else
            {
                string existe = datos.Existe(email);
                if(existe == "1")
                {
                    return "El usuario ya existe";
                }

                obj.IdUsuario = idusuario;
                obj.IdRol = idrol;
                obj.Nombre = nombre;
                obj.TipoDocumento = tipodocumento;
                obj.NumeroDocumento = numeroDocumento;
                obj.Direccion = direccion;
                obj.Telefono = telefono;
                obj.Email = email;
                obj.Clave = clave;
                return datos.Actualizar(obj);
                }
            }
        public static string Eliminar(int id)
        {
            DUsuario datos = new DUsuario();
            return datos.Eliminar(id);
        }

        public static string Activar(int id)
        {
            DUsuario datos = new DUsuario();
            return datos.Activar(id);
        }

        public static string Desactivar(int id)
        {
            DUsuario datos = new DUsuario();
            return datos.Desactivar(id);
        }
        public static DataTable Login(string email, string clave)
        {
            //instanciamos DCategoria
            DUsuario datos = new DUsuario();
            return datos.Login(email, clave);
        }
    }
    
}
