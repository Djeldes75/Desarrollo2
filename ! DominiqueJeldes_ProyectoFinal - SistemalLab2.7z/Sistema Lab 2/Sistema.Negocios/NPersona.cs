﻿using Sistema.Datos;
using Sistema.Entidad;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema.Negocios
{
    public class NPersona
    {
        public static DataTable Listar()
        {
            DPersona datos = new DPersona();
            return datos.Listar();
        }

        public static DataTable ListarProveedores()
        {
            DPersona datos = new DPersona();
            return datos.ListarProveedores();
        }

        public static DataTable ListarClientes()
        {
            DPersona datos = new DPersona();
            return datos.ListarClientes();
        }
        //Fin Listar


        public static DataTable Buscar(string valor)
        {
            //instanciamos DCategoria
            DPersona datos = new DPersona();
            return datos.Buscar(valor);
        }

        public static DataTable BuscarProveedores(string valor)
        {
            //instanciamos DCategoria
            DPersona datos = new DPersona();
            return datos.BuscarProveedores(valor);
        }

        public static DataTable BuscarClientes(string valor)
        {
            //instanciamos DCategoria
            DPersona datos = new DPersona();
            return datos.BuscarClientes(valor);
        }
        //Fin Buscar

        public static string Insertar(string tipoPersona, string nombre, string tipodocumento,
            string numeroDocumento, string direccion, string telefono, string email)
        {
            //instanciamos a la clase Dcategoria
            DPersona datos = new DPersona();

            //Primero debemos validar si la categoria existe
            string existe = datos.Existe(nombre);
            if (existe.Equals("1"))
            {
                return "La Persona ya Existe";
            }
            else
            {
                Persona obj = new Persona();
                obj.Nombre = nombre;
                obj.TipoPersona = tipoPersona;
                obj.TipoDocumento = tipodocumento;
                obj.NumDocumento = numeroDocumento;
                obj.Direccion = direccion;
                obj.Telefono = telefono;
                obj.Email = email;
                return datos.Insertar(obj);
            }
        }

        public static string Actualizar(int idPersona, string tipoPersona, string nombreAnt,
            string nombre, string tipodocumento, string numDocumento, string direccion,
            string telefono, string email)
        {
            //Instanciamos a la classe DCategoria 
            DPersona datos = new DPersona();
            Persona obj = new Persona();

            if (nombreAnt.Equals(nombre))
            {
                //la persona existe, por ende solo creamos el objeto
                obj.IdPersona = idPersona;
                obj.TipoPersona = tipoPersona;
                obj.Nombre = nombre;
                obj.TipoDocumento = tipodocumento;
                obj.NumDocumento = numDocumento;
                obj.Direccion = direccion;
                obj.Telefono = telefono;
                obj.Email = email;
                return datos.Actualizar(obj);
            }
            else
            {
                string existe = datos.Existe(email);
                if (existe == "1")
                {
                    return "El usuario ya existe";
                }
                obj.IdPersona = idPersona;
                obj.TipoPersona = tipoPersona;
                obj.Nombre = nombre;
                obj.TipoDocumento = tipodocumento;
                obj.NumDocumento = numDocumento;
                obj.Direccion = direccion;
                obj.Telefono = telefono;
                obj.Email = email;
                return datos.Actualizar(obj);
            }
        }

        public static string Eliminar(int id)
        {
            DPersona datos = new DPersona();
            return datos.Eliminar(id);
        }
    }
}
