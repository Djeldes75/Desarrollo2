﻿using Sistema.Datos;
using Sistema.Entidad;
using System.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema.Negocios
{
    public class NArticulo
    {
        public static DataTable Listar()
        {
            //instanciar a la clase DArticulo
            DArticulo datos = new DArticulo();
            return datos.Listar();
        }

        //buscar categorias

        public static DataTable Buscar(string valor)
        {
            //instanciamos DCategoria
            DArticulo datos = new DArticulo();
            return datos.Buscar(valor);
        }
        public static DataTable BuscarCodigo(string valor)
        {
            //instanciamos DCategoria
            DArticulo datos = new DArticulo();
            return datos.BuscarCodigo(valor);
        }
        public static DataTable BuscarCodigoVentas(string valor)
        {
            //instanciamos DCategoria
            DArticulo datos = new DArticulo();
            return datos.BuscarCodigoVentas(valor);
        }
        //Fin del metodo Buscar

        //Insertar nueva categoria

        public static string Insertar(string nombre, string descripcion, int categoria, string codigo,
            decimal precio_venta, int stock, string imagen)
        {
            //instanciamos a la clase Dcategoria
            DArticulo datos = new DArticulo();

            //Primero debemos validar si la categoria existe
            string existe = datos.Existe(nombre);
            if (existe.Equals("1"))
            {
                return "El Articulo ya Existe";
            }
            else
            {
                Articulo obj = new Articulo();
                obj.Nombre = nombre;
                obj.Descripcion = descripcion;
                obj.Idcategoria = categoria;
                obj.Codigo = codigo;
                obj.Precio_venta = precio_venta;
                obj.Stock = stock;
                obj.Imagen = imagen;
                //insertamos la categoria
                return datos.Insertar(obj);
            }

        }

        public static DataTable FiltroCategoria()
        {
            DArticulo datos = new DArticulo();
            return datos.FiltroCategoria();
        }

        public static string Actualizar(int idarticulo, string nombreAnt, string nombre, string descripcion,
            int idcategoria, string codigo, decimal precio_venta, int stock, string imagen)
        {
            //Instanciamos a la classe DCategoria 
            DArticulo datos = new DArticulo();
            Articulo obj = new Articulo();

            if (nombreAnt.Equals(nombre))
            {
                //la categoria existe, por ende solo creamos el objeto
                obj.Nombre = nombre;
                obj.Idarticulo = idarticulo;
                obj.Descripcion = descripcion;
                obj.Idcategoria = idcategoria;
                obj.Codigo = codigo;
                obj.Precio_venta = precio_venta;
                obj.Stock = stock;
                obj.Imagen = imagen;
                return datos.Actualizar(obj);
            }
            else
            {
                //el usuario quiere modificar el nombre de la categoria, debemos investigar si la misma
                //existe en la base de datos antes de actualizarlo
                string Existe = datos.Existe(nombre);
                if (Existe.Equals("1"))
                {
                    return "La categoria ya existe";
                }
                else
                {
                    obj.Nombre = nombre;
                    obj.Idarticulo = idarticulo;
                    obj.Descripcion = descripcion;
                    obj.Idcategoria = idcategoria;
                    obj.Codigo = codigo;
                    obj.Precio_venta = precio_venta;
                    obj.Stock = stock;
                    obj.Imagen = imagen;

                    return datos.Actualizar(obj);
                }
            }
        }
        //Fin del metodo Actualizar

        //Eliminar una categoria
        public static string Eliminar(int id)
        {
            DArticulo datos = new DArticulo();
            return datos.Eliminar(id);
        }
        //Fin del metodo eliminar

        //activar una categoria
        public static string Activar(int id)
        {
            DArticulo datos = new DArticulo();
            return datos.Activar(id);
        }

        //Desactivar una categoria
        public static string Desctivar(int id)
        {
            DArticulo datos = new DArticulo();
            return datos.Desactivar(id);
        }
    }
}
