﻿using Sistema.Datos;
using Sistema.Entidad;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema.Negocios
{
    public class NCategoria
    {
        //listar categorias 
        public static DataTable Listar()
        {
            //instanciar a la clase DCategoria
            DCategoria datos  = new DCategoria();
            return datos.Listar();
        }

        //buscar categorias

        public static DataTable Buscar(string valor)
        {
            //instanciamos DCategoria
            DCategoria datos = new DCategoria();
            return datos.Buscar(valor);
        }
        //Fin del metodo Buscar

        //Insertar nueva categoria

        public static string Insertar(string nombre, string descripcion)
        {
            //instanciamos a la clase Dcategoria
            DCategoria datos = new DCategoria();

            //Primero debemos validar si la categoria existe
            string existe = datos.Existe(nombre);
            if (existe.Equals("1"))
            {
                return "La Categoría ya Existe";
            }
            else
            {
                Categoria obj = new Categoria();
                obj.Nombre = nombre;
                obj.Descripcion = descripcion;
                //insertamos la categoria
                return datos.Insertar(obj);
            }

        }
        //fin del metodo

        //actualizar una categoria

        public static string Actualizar(int id, string nombreAnt, string nombre, string descripcion)
        {
            //Instanciamos a la classe DCategoria 
            DCategoria datos = new DCategoria();
            Categoria obj = new Categoria();

            if (nombreAnt.Equals(nombre))
            {
                //la categoria existe, por ende solo creamos el objeto
                obj.Nombre = nombre;
                obj.Idcategoria = id;
                obj.Descripcion = descripcion;
                return datos.Actualizar(obj);
            }
            else
            {
                //el usuario quiere modificar el nombre de la categoria, debemos investigar si la misma
                //existe en la base de datos antes de actualizarlo
                string Existe = datos.Existe(nombre);
                if (Existe.Equals("1"))
                {
                    return "La categoria ya existe";
                }
                else
                {
                    obj.Nombre = nombre;
                    obj.Idcategoria = id;
                    obj.Descripcion = descripcion;
                    return datos.Actualizar(obj);
                }
            }
        }
        //Fin del metodo Actualizar

        //Eliminar una categoria
        public static string Eliminar(int id)
        {
            DCategoria datos = new DCategoria();
            return datos.Eliminar(id);
        }
        //Fin del metodo eliminar

        //activar una categoria
        public static string Activar (int id)
        {
            DCategoria datos = new DCategoria();
            return datos.Activar(id);
        }

        //Desactivar una categoria
        public static string Desctivar(int id)
        {
            DCategoria datos = new DCategoria();
            return datos.Desactivar(id);
        }
    }   
}
